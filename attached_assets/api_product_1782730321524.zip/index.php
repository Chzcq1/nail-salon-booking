<?php
// index.php — แคตตาล็อกสินค้าแบบเรียบง่าย + Modal รายละเอียด

$apiUrl = 'https://gafiwshop.xyz/api/api_product';

// ---- ดึงข้อมูลด้วย cURL (timeout + เช็ค error) ----
$ch = curl_init($apiUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_CONNECTTIMEOUT => 5,
    CURLOPT_TIMEOUT => 10,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_SSL_VERIFYHOST => 2,
    CURLOPT_HTTPHEADER => ['Accept: application/json'],
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr  = curl_error($ch);
curl_close($ch);

// ---- แปลงผลลัพธ์ ----
$products = [];
$errorMsg = '';
if ($response && $httpCode === 200) {
    $json = json_decode($response, true);
    if (json_last_error() === JSON_ERROR_NONE && !empty($json['ok'])) {
        $products = $json['data'] ?? [];
    } else {
        $errorMsg = 'รูปแบบ JSON ไม่ถูกต้อง หรือ ok=false';
    }
} else {
    $errorMsg = 'เชื่อมต่อ API ไม่สำเร็จ (HTTP ' . ($httpCode ?: '0') . ') ' . ($curlErr ?: '');
}

$productsJson = json_encode($products, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>รายการสินค้า</title>
<link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
:root{
    --bg: #f7fafc;
    --grad1: #fff7ed;  /* อบอุ่นนิด ๆ */
    --grad2: #e0f2fe;  /* ฟ้าสดใส */
    --card: #ffffff;
    --text: #1f2937;
    --muted:#6b7280;
    --primary:#ff8c00;
    --primary-2:#f97316;
    --border:#e5e7eb;
    --success:#16a34a;
    --danger:#ef4444;
    --shadow: 0 10px 30px rgba(17,24,39,.06);
}

*{box-sizing:border-box}
html,body{height:100%}
body{
    margin:0;
    font-family:'Prompt',system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;
    color:var(--text);
    background:
      radial-gradient(1200px 800px at -10% -20%, var(--grad1), transparent 60%),
      radial-gradient(1000px 800px at 110% 10%, var(--grad2), transparent 60%),
      var(--bg);
}

/* Header */
.container{max-width:1180px;margin:0 auto;padding:28px 18px 40px}
.header{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;flex-wrap:wrap}
.h-title{font-size:2rem;line-height:1.1;margin:0;font-weight:700;letter-spacing:.2px;color:#0f172a}
.h-sub{color:var(--muted);margin:6px 0 0 2px}
.badge{background:#fff;border:1px dashed var(--border);padding:5px 10px;border-radius:999px;color:#64748b;font-weight:600}

/* Toolbar */
.toolbar{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:18px 0}
.input{
    flex:1; min-width:240px; background:#fff; border:1px solid var(--border); border-radius:14px;
    padding:12px 14px; font-size:1rem; outline:none; transition:border .2s, box-shadow .2s;
}
.input:focus{border-color:#93c5fd; box-shadow:0 0 0 4px rgba(59,130,246,.1)}
.select{
    background:#fff;border:1px solid var(--border);border-radius:14px;padding:12px 14px;font-size:1rem;cursor:pointer
}
.btn{
    background:linear-gradient(135deg,var(--primary),var(--primary-2));
    color:#fff;border:none;border-radius:14px;padding:12px 18px;cursor:pointer;font-weight:700;letter-spacing:.2px;
    box-shadow:0 6px 18px rgba(249,115,22,.2); transition:transform .08s ease, filter .2s;
}
.btn:hover{filter:brightness(1.05)}
.btn:active{transform:translateY(1px)}

/* Category chips */
.chips{display:flex;gap:8px;overflow:auto;padding:2px 2px 10px 2px}
.chip{
    flex:0 0 auto;background:#ffffffa8; backdrop-filter: blur(6px);
    border:1px solid var(--border); color:#0f172a; padding:8px 12px;border-radius:999px; cursor:pointer;
    transition: all .2s; font-weight:600; font-size:.95rem;
}
.chip:hover{transform:translateY(-1px)}
.chip.active{background:#ffedd5;border-color:#fdba74;color:#9a3412}

/* Grid + Card */
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-top:14px}
@media (max-width:1024px){.grid{grid-template-columns:repeat(3,1fr)}}
@media (max-width:768px){.grid{grid-template-columns:repeat(2,1fr)}}
@media (max-width:520px){.grid{grid-template-columns:1fr}}

.card{
    background:var(--card); border:1px solid var(--border); border-radius:18px; overflow:hidden;
    box-shadow:var(--shadow);
    transform:translateY(6px); opacity:0; animation:fadeInUp .5s forwards;
}
@keyframes fadeInUp{
    to{transform:translateY(0);opacity:1}
}
.thumb{
    width:100%; aspect-ratio: 16/10; object-fit:cover; background:linear-gradient(120deg,#fff,#f8fafc);
    transition:transform .5s ease;
}
.card:hover .thumb{transform:scale(1.03)}
.body{padding:14px 14px 10px}
.name{font-size:1.06rem;font-weight:700;line-height:1.3;margin:0 0 6px}
.row{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.price{font-weight:800}
.vip{font-weight:700;color:var(--success)}
.stock{margin-left:auto;font-size:.85rem;padding:4px 10px;border-radius:999px;border:1px solid var(--border);background:#f8fafc}
.stock.zero{background:#fee2e2;border-color:#fecaca;color:#991b1b}

/* Card footer */
.footer{padding:12px 14px;border-top:1px solid var(--border);display:flex;gap:10px}
.btn-outline{
    background:#fff;border:1px solid var(--border);padding:10px 14px;border-radius:12px;cursor:pointer;font-weight:700;
}
.btn-outline:hover{background:#f8fafc}

/* Count & time */
.meta{display:flex;justify-content:space-between;align-items:center;margin-top:8px;color:var(--muted);font-size:.95rem;flex-wrap:wrap}

/* Modal */
.modal{
    position:fixed; inset:0; display:flex; align-items:center; justify-content:center;
    padding:22px; background:rgba(15,23,42,.38); backdrop-filter: blur(4px);
    opacity:0; pointer-events:none; transition:opacity .2s ease;
}
.modal.active{opacity:1; pointer-events:auto}
.modal-card{
    width:min(680px, 96vw); max-height:92vh; overflow:auto;
    background:#fff; border:1px solid var(--border); border-radius:20px; box-shadow:0 20px 60px rgba(2,6,23,.25);
    transform:translateY(10px) scale(.98); opacity:0; animation:pop .22s .05s forwards;
}
@keyframes pop{
    to{transform:translateY(0) scale(1); opacity:1}
}
.m-head{display:flex;justify-content:space-between;align-items:center;padding:14px 16px;border-bottom:1px solid var(--border)}
.m-title{font-size:1.2rem;font-weight:700;margin:0}
.m-close{background:transparent;border:none;font-size:1.4rem;cursor:pointer;color:#475569}
.m-body{padding:14px 16px;display:grid;grid-template-columns:160px 1fr;gap:14px}
@media (max-width:560px){.m-body{grid-template-columns:1fr}}
.m-img{width:100%;aspect-ratio:1/1;object-fit:cover;border-radius:12px;border:1px solid var(--border);background:#fff}
.m-line{margin:4px 0;color:#64748b}
.m-price{display:flex;align-items:center;gap:10px;margin:8px 0 2px}
.m-price .price{font-size:1.15rem}
.details{
    white-space:pre-line; color:#111827; background:#f9fafb; border:1px solid var(--border); border-radius:12px;
    padding:12px; line-height:1.55; font-size:.98rem;
}
.m-actions{display:flex;gap:10px;justify-content:flex-end;padding:12px 16px;border-top:1px solid var(--border)}
/* small helpers */
.hide{display:none}
.err{background:#fff1f2;border:1px solid #fecdd3;color:#9f1239;padding:12px;border-radius:12px;margin-top:14px}
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <div>
            <h1 class="h-title">รายการสินค้า</h1>
            <div class="h-sub">เลือกชมสินค้าของคุณอย่างสบายตา • คลิกดูรายละเอียดเพื่ออ่านข้อมูลเต็ม</div>
        </div>
        <span class="badge">API สาธารณะ</span>
    </div>

    <?php if ($errorMsg): ?>
        <div class="err">เกิดข้อผิดพลาดในการดึงข้อมูล: <?= htmlspecialchars($errorMsg, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <div class="toolbar">
        <input id="q" class="input" type="search" placeholder="ค้นหาชื่อ/หมวด/รหัสสินค้า...">
        <select id="sort" class="select">
            <option value="new">เรียงตามลำดับ</option>
            <option value="price_asc">ราคาต่ำ → สูง</option>
            <option value="price_desc">ราคาสูง → ต่ำ</option>
            <option value="name_asc">ชื่อ A → Z</option>
            <option value="name_desc">ชื่อ Z → A</option>
        </select>
        <button class="btn" id="refresh" onclick="location.reload()">รีเฟรช</button>
    </div>

    <!-- category chips -->
    <div id="chips" class="chips"></div>

    <div class="meta">
        <div id="count">0 รายการ</div>
        <div>อัปเดตล่าสุด: <?= date('Y-m-d H:i:s') ?></div>
    </div>

    <div id="grid" class="grid"></div>
</div>

<!-- Modal -->
<div id="modal" class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
  <div class="modal-card">
    <div class="m-head">
      <h3 id="modalTitle" class="m-title">รายละเอียดสินค้า</h3>
      <button class="m-close" id="modalClose" aria-label="ปิด">×</button>
    </div>
    <div class="m-body">
      <img id="mImg" class="m-img" alt="ภาพสินค้า">
      <div>
        <div id="mName" style="font-weight:700;font-size:1.1rem;margin-bottom:4px">ชื่อสินค้า</div>
        <div id="mMeta" class="m-line">หมวด • รหัสสินค้า</div>
        <div class="m-price">
            <div id="mPrice" class="price">฿0</div>
            <div id="mVip" class="vip hide">VIP ฿0</div>
            <div id="mStock" class="stock" style="margin-left:auto">สต็อก: 0</div>
        </div>
        <div id="mDetails" class="details" style="margin-top:10px;">รายละเอียด...</div>
      </div>
    </div>
    <div class="m-actions">
      <button class="btn-outline" id="copyBtn">คัดลอกรายละเอียด</button>
      <button class="btn" id="buyBtn">สั่งซื้อ</button>
    </div>
  </div>
</div>

<script>
// ---- Data ----
const PRODUCTS = <?php echo $productsJson ?: '[]'; ?>;

// ---- Elements ----
const grid = document.getElementById('grid');
const chipsWrap = document.getElementById('chips');
const q = document.getElementById('q');
const sortSel = document.getElementById('sort');
const countEl = document.getElementById('count');

// Modal elements
const modal = document.getElementById('modal');
const modalClose = document.getElementById('modalClose');
const mImg = document.getElementById('mImg');
const mName = document.getElementById('mName');
const mMeta = document.getElementById('mMeta');
const mPrice = document.getElementById('mPrice');
const mVip = document.getElementById('mVip');
const mStock = document.getElementById('mStock');
const mDetails = document.getElementById('mDetails');
const copyBtn = document.getElementById('copyBtn');
const buyBtn = document.getElementById('buyBtn');

let ACTIVE_CAT = 'all';
let CURRENT = null;

// ---- Utils ----
const safeText = s => (s ?? '').toString();
const toNum = v => Number((v ?? '').toString().replace(/[^0-9.]+/g,'') || 0);
const baht = n => '฿' + Number(n||0).toLocaleString('th-TH');

function cleanDetails(input) {
  let s = input || '';
  // แปลงแท็กที่ใช้จัดบรรทัด -> \n
  s = s.replace(/<br\s*\/?>/gi, '\n')
       .replace(/<\/p>/gi, '\n')
       .replace(/<li>/gi, '• ')
       .replace(/<\/li>/gi, '\n')
       .replace(/<\/?ul>/gi, '');

  // ลบแท็ก HTML ที่เหลือทั้งหมด
  s = s.replace(/<\/?[^>]+>/g, '');

  // ถอดรหัส entity (&lt; &gt; &amp; ฯลฯ) เพื่อให้เห็นอักขระจริง เช่น </>
  const ta = document.createElement('textarea');
  ta.innerHTML = s;
  s = ta.value;

  // เกลาเว้นบรรทัด
  s = s.replace(/\r\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  return s;
}

function validImg(url){
  return /^https?:\/\//i.test(url||'');
}

// ---- Build category chips ----
function buildChips(){
  const cats = Array.from(new Set(PRODUCTS.map(p => safeText(p.type_menu).trim()).filter(Boolean))).sort((a,b)=>a.localeCompare(b,'th'));
  chipsWrap.innerHTML = '';
  const allChip = chipEl('ทั้งหมด', 'all');
  chipsWrap.appendChild(allChip);
  cats.forEach(c => chipsWrap.appendChild(chipEl(c, c)));
  setActiveChip(ACTIVE_CAT);
}
function chipEl(label, val){
  const el = document.createElement('button');
  el.className = 'chip';
  el.textContent = label;
  el.onclick = () => { ACTIVE_CAT = val; apply(); setActiveChip(val); };
  el.dataset.value = val;
  return el;
}
function setActiveChip(val){
  document.querySelectorAll('.chip').forEach(c => c.classList.toggle('active', c.dataset.value === val));
}

// ---- Render grid ----
function render(items){
  grid.innerHTML = '';
  if(!items.length){
    grid.innerHTML = '<div class="err" style="grid-column:1/-1;text-align:center">ไม่พบสินค้า</div>';
    countEl.textContent = '0 รายการ';
    return;
  }
  items.forEach((p,i)=>{
    const name = safeText(p.name);
    const img  = safeText(p.imageapi);
    const price = toNum(p.price);
    const priceVip = toNum(p.pricevip);
    const stock = toNum(p.stock);
    const menu  = safeText(p.type_menu);
    const typeId= safeText(p.type_id);

    const card = document.createElement('div');
    card.className = 'card';
    card.style.animationDelay = (i * 0.03)+'s';

    const im = document.createElement('img');
    im.className = 'thumb';
    im.alt = name || 'product';
    if(validImg(img)) im.src = img;
    card.appendChild(im);

    const body = document.createElement('div');
    body.className = 'body';

    const nm = document.createElement('div');
    nm.className = 'name';
    nm.textContent = name || 'ไม่ระบุชื่อสินค้า';
    body.appendChild(nm);

    const row = document.createElement('div');
    row.className = 'row';

    const pe = document.createElement('div');
    pe.className = 'price';
    pe.textContent = baht(price);
    row.appendChild(pe);

    const vip = document.createElement('div');
    vip.className = 'vip';
    if (priceVip && priceVip < price){
      vip.textContent = 'VIP ' + baht(priceVip);
      row.appendChild(vip);
    }

    const st = document.createElement('div');
    st.className = 'stock' + (stock<=0 ? ' zero':'');
    st.textContent = stock>0 ? `สต็อก: ${stock}` : 'หมดสต็อก';
    row.appendChild(st);

    body.appendChild(row);
    card.appendChild(body);

    const foot = document.createElement('div');
    foot.className = 'footer';
    const infoBtn = document.createElement('button');
    infoBtn.className = 'btn-outline';
    infoBtn.textContent = 'รายละเอียด';
    infoBtn.onclick = () => openModal(p);
    foot.appendChild(infoBtn);

    const buy = document.createElement('button');
    buy.className = 'btn';
    buy.textContent = 'สั่งซื้อ';
    buy.disabled = stock<=0;
    buy.onclick = () => location.href = `product.php?id=${encodeURIComponent(typeId)}`;
    foot.appendChild(buy);

    card.appendChild(foot);
    grid.appendChild(card);
  });
  countEl.textContent = `${items.length.toLocaleString('th-TH')} รายการ`;
}

// ---- Filter + Sort + Search ----
function apply(){
  const term = q.value.trim().toLowerCase();
  let list = PRODUCTS.slice();

  if (ACTIVE_CAT !== 'all'){
    list = list.filter(p => safeText(p.type_menu).trim() === ACTIVE_CAT);
  }
  if (term){
    list = list.filter(p => {
      const hay = [p.name,p.type_menu,p.type_id].map(safeText).join(' ').toLowerCase();
      return hay.includes(term);
    });
  }
  switch (sortSel.value){
    case 'price_asc':  list.sort((a,b)=>toNum(a.price)-toNum(b.price)); break;
    case 'price_desc': list.sort((a,b)=>toNum(b.price)-toNum(a.price)); break;
    case 'name_asc':   list.sort((a,b)=>safeText(a.name).localeCompare(safeText(b.name),'th')); break;
    case 'name_desc':  list.sort((a,b)=>safeText(b.name).localeCompare(safeText(a.name),'th')); break;
    default: /* keep original order */ break;
  }
  render(list);
}

// ---- Modal ----
function openModal(p){
  CURRENT = p;
  const name = safeText(p.name);
  const img = safeText(p.imageapi);
  const price = toNum(p.price);
  const priceVip = toNum(p.pricevip);
  const stock = toNum(p.stock);
  const menu  = safeText(p.type_menu);
  const typeId= safeText(p.type_id);
  const details = cleanDetails(safeText(p.details));

  document.getElementById('modalTitle').textContent = 'รายละเอียดสินค้า';
  mName.textContent = name || 'ไม่ระบุชื่อสินค้า';
  mMeta.textContent = (menu?`หมวด: ${menu}`:'หมวด: -') + (typeId?` • รหัส: ${typeId}`:'');
  mPrice.textContent = baht(price);
  if (priceVip && priceVip < price){
    mVip.classList.remove('hide');
    mVip.textContent = 'VIP ' + baht(priceVip);
  } else {
    mVip.classList.add('hide');
  }
  mStock.textContent = stock>0 ? `สต็อก: ${stock}` : 'หมดสต็อก';
  mStock.className = 'stock' + (stock<=0 ? ' zero':'');
  mDetails.textContent = details || 'ไม่มีรายละเอียด';

  if(validImg(img)) { mImg.src = img; mImg.classList.remove('hide'); }
  else { mImg.removeAttribute('src'); mImg.classList.add('hide'); }

  buyBtn.disabled = stock<=0;
  buyBtn.onclick = () => location.href = `product.php?id=${encodeURIComponent(typeId)}`;

  modal.classList.add('active');
  // trap focus เบา ๆ
  setTimeout(()=>modalClose.focus(), 10);
}
function closeModal(){
  modal.classList.remove('active');
  CURRENT = null;
}
modal.addEventListener('click', (e)=>{ if(e.target === modal) closeModal(); });
modalClose.addEventListener('click', closeModal);
document.addEventListener('keydown', (e)=>{ if(e.key === 'Escape') closeModal(); });

copyBtn.addEventListener('click', ()=>{
  const lines = [
    mName.textContent,
    mMeta.textContent,
    mPrice.textContent + (mVip.classList.contains('hide')?'':` • ${mVip.textContent}`),
    mStock.textContent,
    '',
    mDetails.textContent
  ].join('\n');
  navigator.clipboard.writeText(lines).then(()=>{
    copyBtn.textContent = 'คัดลอกแล้ว ✓';
    setTimeout(()=>copyBtn.textContent='คัดลอกรายละเอียด', 1200);
  });
});

// ---- Init ----
document.addEventListener('DOMContentLoaded', ()=>{
  buildChips();
  render(PRODUCTS);

  // debounce ค้นหา
  q.addEventListener('input', ()=>{
    clearTimeout(q._t); q._t = setTimeout(apply, 180);
  });
  sortSel.addEventListener('change', apply);
});
</script>
</body>
</html>
