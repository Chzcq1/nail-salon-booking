<?php

$url = "https://gafiwshop.xyz/api/api_buy";
$keyapi = "ใส่ key ของคุณ";
$type_id = "รหัสสินค้า"; //รหัสทดลอง QNQRNMWWUIEAMJJSMICM
$username_buy = ""; // อันนี้ใส่ก็ได้ไม่ใส่ก็ได้ หากดึงประวัติจาก api แนะนำให้ใส่ หากคุณเก็บรายละเอียดสั่งซื้อไว้ SQL แนะนำไม่ต้องใส่ก็ได้ครับ
// **แนะนำเพิ่มเติมหากดึงจาก api เวลาเคลมสินค้าจะไม่ต้องไปแก้ไขใน SQL ระบบจะดึงจาก API ต้นทางอัตโนมัติ

$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => "$url",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => "keyapi=$keyapi&type_id=$type_id&username_buy=$username_buy",
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/x-www-form-urlencoded',
    'Cookie: PHPSESSID=f6e69f8a53630db985d0296bc00611d1'
  ),
));
$response = curl_exec($curl);
curl_close($curl);

$payload = json_decode($response, true);
$status = $payload['status']; // สเตตัส
$code = $payload['error']['code']; // error code
$message = $payload['error']['message']; // error message

// สั่งซื้อสำเร็จ
if($status == 'success'){
	
$d = $payload['data'];

///// ชุดข้อมูลนี้ หากลูกค้าเก็บไว้ใน SQL สามารถ เพิ่มตัว SQL ได้เลย
$uid = $d["uid"];  // ดึงข้อมูลไอดี
$name = $d["name"]; // ดึงข้อมูลชื่อสินค้า
$imageapi = $d["imageapi"];  // ดึงรูปสินค้า
$textdb = $d["textdb"]; // ดึงรายละเอียดสินค้า
$point = $d["point"];  // ดึงราคาสั่งซื้อ
$date = $d["date"]; // เวลาสั่งซื้อ
/////////////////////////////////////////////////
echo json_encode(array('status' => "success", 'msg' => "สั่งซื้อสำเร็จ"));	 //ตอบกลับสั่งซื้อสำเร็จ
	} else {
echo json_encode(array('status' => "error", 'msg' => "$message"));	// ตอบกลับหาก Error
 }