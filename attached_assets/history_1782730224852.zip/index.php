<?php

$url = "https://gafiwshop.xyz/api/api_history";
$keyapi = "ใส่ keyapi ของคุณ";
$limit = "จำนวนที่จะให้แสดง"; // หากให้แสดงทั้งหมดให้ใส่ all 
$username_buy = "ใส่ชื่อผู้ใช้ที่สั่งซื้อ"; // อันนี้ใส่ก็ได้ไม่ใส่ก็ได้ หากใส่ระบบจะดึงแค่รหัสของผู้ใช้คนนั้น


$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://gafiwshop.xyz/api/api_history?keyapi=$keyapi&limit=$limit&username_buy=$username_buy",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Cookie: PHPSESSID=f6e69f8a53630db985d0296bc00611d1'
  ),
));
$response = curl_exec($curl);
curl_close($curl);

$payload = json_decode($response);


// ปรับแต่งข้อมูลจากด้านล่างนี้
foreach ($payload->data as $item) {

$item->id;  // ดึงข้อมูลไอดี
$item->name; // ดึงข้อมูลชื่อสินค้า
$item->details;  // ดึงข้อมูลรายละเอียด
$item->price; // ดึงจำนวนเงิน
$item->status;  // ดึงข้อมูลสเตตัส 0=บัญชีปกติ 1=รอเคลม 2=เคลมสำเร็จ 3=รหัสอัพเดท 4=บัญชีโดนแบน 5=เคลมบัญชีใหม่ 6=คืนเงิน 7=เคลมไม่สำเร็จ
$item->date; // เวลาสั่งซื้อ

};