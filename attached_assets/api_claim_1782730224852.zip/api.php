<?php

$keyapi = "โปรดใส่ keyapi ของคุณ";  // เปลี่ยนเป็น API Key ของคุณ
$order_id = "*****";                        // เปลี่ยนเป็นเลขออเดอร์ที่ต้องการเคลม
$claim_reason = "ไม่ได้รับสินค้า";            // เปลี่ยนเป็นสาเหตุการเคลม

$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://gafiwshop.xyz/api/api_claim',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => array(
        'keyapi' => $keyapi,
        'order_id' => $order_id,
        'reason' => $claim_reason
    ),
));

// ทำการเรียก API
$response = curl_exec($curl);
$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

// ตรวจสอบข้อผิดพลาด
if (curl_errno($curl)) {
    echo "❌ เกิดข้อผิดพลาด: " . curl_error($curl) . "\n";
    curl_close($curl);
    exit;
}

curl_close($curl);
$result = json_decode($response, true);

if ($result) {
    if ($result['status'] === 'success') {
        echo "✅ สถานะ: สำเร็จ\n";
        echo "💬 ข้อความ: {$result['msg']}\n";
        if (isset($result['data'])) {
            echo "\n📊 ข้อมูลเคลม:\n";
            echo "  - Order ID: {$result['data']['order_id']}\n";
            echo "  - เวลาเคลม: {$result['data']['claim_time']}\n";
        }
    } else {
        echo "❌ สถานะ: ล้มเหลว\n";
        echo "⚠️ ข้อความ: {$result['msg']}\n";
    }
    
    echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

} else {
    echo "❌ ไม่สามารถแปลง JSON ได้\n";
    echo "Raw Response: $response\n";
}


?>
