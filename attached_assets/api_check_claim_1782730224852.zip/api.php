<?php
$keyapi = "โปรดใส่ keyapi ของคุณ";  // เปลี่ยนเป็น API Key ของคุณ
$order_id = "*****";                        // เปลี่ยนเป็นเลขออเดอร์ที่ต้องการเคลม

$curl = curl_init();
$postfields = array('keyapi' => $keyapi);
if (!empty($order_id)) {
    $postfields['order_id'] = $order_id;
}
curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://gafiwshop.xyz/api/v1/check_claim_status.php',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => $postfields,
));

// ทำการเรียก API
$response = curl_exec($curl);
$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

// ตรวจสอบข้อผิดพลาด
if (curl_errno($curl)) {
    echo "❌ เกิดข้อผิดพลาด: " . curl_error($curl) . "\n";
    curl_close($curl);
    exit;
}

curl_close($curl);

// แปลง JSON เป็น Array
$result = json_decode($response, true);

if ($result) {
    // ตรวจสอบสถานะ
    if ($result['status'] === 'success') {
        echo "✅ สถานะ: สำเร็จ\n";
        echo "💬 ข้อความ: {$result['msg']}\n\n";
        
        // กรณีดึงรายการเดียว
        if (isset($result['data']) && !isset($result['total'])) {
            $data = $result['data'];
            echo "📊 ข้อมูลออเดอร์:\n";
            echo "  🆔 Order ID: {$data['order_id']}\n";
            echo "  🎁 สินค้า: {$data['product_name']}\n";
            echo "  🏷️ ประเภท: {$data['type']}\n";
            echo "  💰 ราคา: {$data['price']} บาท\n";
            echo "  📅 วันที่สั่ง: {$data['order_date']}\n";
            echo "  📊 สถานะเคลม: {$data['status_text']} (#{$data['claim_status']})\n";
            
            if ($data['claim_text']) {
                echo "  📝 สาเหตุเคลม: {$data['claim_text']}\n";
                echo "  🕒 เวลาเคลม: {$data['claim_time']}\n";
            }
        }
        // กรณีดึงหลายรายการ
        elseif (isset($result['total'])) {
            echo "📊 จำนวนทั้งหมด: {$result['total']} รายการ\n\n";
            
            foreach ($result['data'] as $index => $data) {
                $no = $index + 1;
                echo "--- รายการที่ $no ---\n";
                echo "  🆔 Order ID: {$data['order_id']}\n";
                echo "  🎁 สินค้า: {$data['product_name']}\n";
                echo "  💰 ราคา: {$data['price']} บาท\n";
                echo "  📊 สถานะ: {$data['status_text']}\n";
                
                if ($data['claim_text']) {
                    echo "  📝 เคลม: {$data['claim_text']}\n";
                }
                echo "\n";
            }
        }
    } else {
        echo "❌ สถานะ: ล้มเหลว\n";
        echo "⚠️ ข้อความ: {$result['msg']}\n";
    }
    
    // แสดง JSON แบบเต็ม
    echo "\n📦 JSON Response (แบบเต็ม):\n";
    echo "========================================\n";
    echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    echo "\n";
} else {
    echo "❌ ไม่สามารถแปลง JSON ได้\n";
    echo "Raw Response: $response\n";
}

?>
